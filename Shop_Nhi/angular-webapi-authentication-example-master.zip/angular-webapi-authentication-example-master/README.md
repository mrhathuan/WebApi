angular-webapi-authentication-example
=====================================

AngularJS + ASP.NET Web API 2 - Basic HTTP Authentication Example

For a description and full details go to http://jasonwatmore.com/post/2014/12/01/Web-API-2-Basic-HTTP-Authentication-Example.aspx