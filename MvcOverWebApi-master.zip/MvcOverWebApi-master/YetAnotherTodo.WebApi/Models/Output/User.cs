﻿namespace YetAnotherTodo.WebApi.Models.Output
{
    public class User
    {
        public string Id { get; set;} 
    }
}