﻿namespace YetAnotherTodo.Domain
{
    public class UserRole
    {
        public string UserId { get; set; }
        public string RoleId { get; set; }
    }
}