//Loai bang lai
var CATDrivingLicence_Index =function()
{
    //button go view
    this.btnAdminFleet = element(by.css('a[ng-click="main.PUBAdminFleet.Index"]'));
    this.btnDrivingLicence = element(by.css('a[ng-click="main.CATDrivingLicence.Index"]'));

	//button
    this.btnDrivingLicence_AddNew = element(by.css('a[ng-click="DrivingLicence_AddNew($event,DrivingLicence_win,DrivingLicence_vform)"]'));
    this.btnDrivingLicence_Edit =  element(by.css('a[ng-click="DrivingLicence_GridEdit_Click($event,dataItem, DrivingLicence_win,DrivingLicence_vform)"]'));
    this.btnDrivingLicence_Destroy = element(by.css('a[ng-click="DrivingLicence_GridDestroy_Click($event,dataItem)"]'));
    this.btnDrivingLicence_Save = element(by.css('a[ng-click="DrivingLicence_Save_Click($event,DrivingLicence_win,DrivingLicence_vform)"]'));
    this.btnWinClose = element(by.css('a[ng-click="Win_Close($event,DrivingLicence_win)"]'));
    this.btnSetting = element(by.css('a[ng-click="ShowSetting($event,contract_grid)"]'));
    
    // Add Admin Fleet
	this.clickAdminFleet =function()
	{
		this.btnAdminFleet.click();
		browser.sleep(1000);
	};
    
    // Add Driving Licence
	this.clickDrivingLicence =function()
	{
		this.btnDrivingLicence.click();
		browser.sleep(1000);
	};
    
    // Add new
	this.clickNew =function()
	{
		this.btnDrivingLicence_AddNew.click();
		browser.sleep(1000);
	};
    
    // Edit
	this.clickEdit =function()
	{
		this.btnDrivingLicence_Edit.click();
		browser.sleep(1000);
	};
    
     // Add save
	this.clickSave =function()
	{
		this.btnDrivingLicence_Save.click();
		browser.sleep(1000);
	};
    
    // Destroy
	this.clickDelete =function()
	{
		this.btnDrivingLicence_Destroy.click();
		browser.sleep(1000);
	};
    
    // Win close
	this.clickWinClose =function()
	{
		this.btnWinClose.click();
		browser.sleep(1000);
	};
    
    // Setting
	this.clickSetting =function()
	{
		this.btnSetting.click();
		browser.sleep(1000);
	};
    
    this.AddNew = function(Code,DrivingLicenceName,VehicleWeight,TypeOfVehicleName,Description){
        var txtCode = element(by.css("[ng-model='Item.Code']"));
		txtCode.clear();
		txtCode.sendKeys(Code);
        browser.sleep(500);
        var txtLicenceName = element(by.css("[ng-model='Item.DrivingLicenceName']"));
		txtLicenceName.clear();
		txtLicenceName.sendKeys(DrivingLicenceName);
        browser.sleep(500);
        var txtVehicleWeight = element(by.css("[ng-model='Item.VehicleWeight']"));
		txtVehicleWeight.clear();
		txtVehicleWeight.sendKeys(VehicleWeight);
        browser.sleep(500);
        // Chon Loai xe
		var cboVehicle = element(by.css(".cboVehicleOptions.k-input.cus-combobox"));
		cboVehicle.clear();
		cboVehicle.sendKeys(TypeOfVehicleName);
		browser.sleep(300);
		cboVehicle.sendKeys(protractor.Key.ENTER);
        browser.sleep(500);
        var txtDescription = element(by.css("[ng-model='Item.Description']"));
		txtDescription.clear();
		txtDescription.sendKeys(Description);
        
    }
    
};

module.exports=new CATDrivingLicence_Index();