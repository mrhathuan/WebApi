var ORDInspection_Index =function()
{
	
};

module.exports=new ORDInspection_Index();