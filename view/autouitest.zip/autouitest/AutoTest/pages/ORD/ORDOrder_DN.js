var ORDOrder_DN =function()
{
	
};

module.exports=new ORDOrder_DN();