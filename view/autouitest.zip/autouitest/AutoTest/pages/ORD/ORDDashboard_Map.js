var ORDDashboard_Map =function()
{
	
};

module.exports=new ORDDashboard_Map();