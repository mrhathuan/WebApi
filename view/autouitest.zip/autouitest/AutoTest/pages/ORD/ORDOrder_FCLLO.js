var ORDOrder_FCLLO =function()
{	
		//-------------- Tao mot don hang FCLLO --------------------
	this.createFCLOrder = function(OrderCode,RequestDate,LocationFrom,ETD,LocationToID,ETA,ArrayDetail)
	{
		// Ma don hang
		
		var txtCode = element(by.css("[ng-model='Item.Code']"));
		txtCode.clear();
		txtCode.sendKeys(OrderCode);
		// Ngay gui don hang
		var txtRequest = element(by.css("[k-ng-model='Item.RequestDate']"));
		txtRequest.clear();
		txtRequest.sendKeys(RequestDate);
		//Diem nhan hang 
		var cboLocationFrom =  element(by.css(".cboLocationFrom.k-input.cus-combobox"));
		cboLocationFrom.clear();
		cboLocationFrom.sendKeys(LocationFrom);
		browser.sleep(300);
		cboLocationFrom.sendKeys(protractor.Key.ENTER);
		//ETD
		var txtETD = element(by.css("[k-ng-model='Item.ETD']"));
		txtETD.clear();
		txtETD.sendKeys(ETD);
		//Diem giao hang
		var cboLocationTo =  element(by.css(".cboLocationTo.k-input.cus-combobox"));
		cboLocationTo.clear();
		cboLocationTo.sendKeys(LocationToID);
		browser.sleep(300);
		cboLocationTo.sendKeys(protractor.Key.ENTER);
		//ETA
		var txtETA = element(by.css("[k-ng-model='Item.ETA']"));
		txtETA.clear();
		txtETA.sendKeys(ETA);
		// Chon tab chi tiet van chuyen
		browser.sleep(200);
		var tab = element(by.css("li[tabindex='1']"));
		tab.click();
		browser.sleep(1000);
		for(var i = 0; i < ArrayDetail.length; i++)
		{
			// Them danh sach
			element(by.css('[ng-click="ORD_FCLLO_Container_AddNew($event,container_grid)"]')).click();
			browser.sleep(200);
			//Sua don hang
			element(by.css('[ng-click="ORD_FCLLO_Container_Edit($event,container_grid)"]')).click();
			browser.sleep(200);
			//So con
			var txtContainerNo = element(by.model("ContainerEdit.ContainerNo"));
			txtContainerNo.clear();
			txtContainerNo.sendKeys(ArrayDetail[i].ContainerNo);
			// Trong tai 
			var txtTon = element(by.model("ContainerEdit.Ton"));
			txtTon.clear();
			txtTon.sendKeys(ArrayDetail[i].Ton);
			// So Seal 1
			var txtSealNo1 = element(by.model("ContainerEdit.SealNo1"));
			txtSealNo1.clear();
			txtSealNo1.sendKeys(ArrayDetail[i].SealNo1);		
			// So Seal 2
			var txtSealNo2 = element(by.model("ContainerEdit.SealNo2"));
			txtSealNo2.clear();
			txtSealNo2.sendKeys(ArrayDetail[i].SealNo2);
			// Save chi tiet
			element(by.css('[ng-click="ORD_FCLLO_Container_Save($event,container_grid)"]')).click();
			browser.sleep(1000);
		}
		browser.sleep(4000);
		// Save don hang
		element(by.css('[ng-click="ORD_FCLLO_Update($event)"]')).click();
		browser.sleep(1000);
		element(by.css('[ng-click="winmessage_Save_Click($event,winmessage)"]')).click();
		browser.sleep(1000);
		// Quay trang main
		element(by.css('[ng-click="ORD_FCLLO_Back($event)"]')).click();
		browser.sleep(1000);
	};
};

module.exports=new ORDOrder_FCLLO();