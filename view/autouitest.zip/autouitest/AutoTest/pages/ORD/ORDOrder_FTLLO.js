var ORDOrder_FTLLO =function()
{
	//----------------- Tao don hang FTL------------------------
	this.createFTLOrder =function(OrderCode, RequestDate, ETD, ETA, GroupOfVehicle, ArrayDetail)
	{
		// Ma don hang
		
		var txtCode = element(by.css("[ng-model='Item.Code']"));
		txtCode.clear();
		txtCode.sendKeys(OrderCode);
		// Ngay gui don hang
		var txtRequest = element(by.css("[k-ng-model='Item.RequestDate']"));
		txtRequest.clear();
		txtRequest.sendKeys(RequestDate);
		// ETD
		var txtETD = element(by.css("[k-ng-model='Item.ETD']"));
		txtETD.clear();
		txtETD.sendKeys(ETD);
		// ETA
		var txtETA = element(by.css("[k-ng-model='Item.ETA']"));
		txtETA.clear();
		txtETA.sendKeys(ETA);
		// Loai xe
		var cbbGroupOfVehicle = element(by.css(".cboGroupOfVehicle.k-input.cus-combobox"));
		cbbGroupOfVehicle.clear();
		cbbGroupOfVehicle.sendKeys(GroupOfVehicle);
		browser.sleep(300);
		cbbGroupOfVehicle.sendKeys(protractor.Key.ENTER);
		browser.sleep(200);
		// Chon tab chi tiet van chuyen
		browser.sleep(200);
		var tab = element(by.css("li[tabindex='1']"));
		tab.click();
		browser.sleep(1000);
		for(var i = 0; i < ArrayDetail.length; i++)
		{
			// Nhap chi tiet van chuyen
			element(by.css('[ng-click="ORD_FTLLO_Product_AddNew($event,product_grid)"]')).click();
			browser.sleep(500);
			// Số lượng
			var txtQuantity = element(by.model("ProductEdit.Quantity"));
			txtQuantity.clear();
			txtQuantity.sendKeys( ArrayDetail[i].Quantity);
			// Khối
			var txtCBM = element(by.model("ProductEdit.CBM"));
			txtCBM.clear();
			txtCBM.sendKeys(ArrayDetail[i].CBM);
			// Tấn
			var txtTON = element(by.model("ProductEdit.Weight"));
			txtTON.clear();
			txtTON.sendKeys(ArrayDetail[i].Ton);
			// SO
			var txtSO = element(by.model("ProductEdit.SOCode"));
			txtSO.clear();
			txtSO.sendKeys(ArrayDetail[i].SO);
			// DN
			var txtDN = element(by.model("ProductEdit.DNCode"));
			txtDN.clear();
			txtDN.sendKeys(ArrayDetail[i].DN);
			// Save chi tiet
			element(by.css('[ng-click="ORD_FTLLO_Product_Save($event,product_grid)"]')).click();
			browser.sleep(1000);
		}
	
		// Save don hang
		element(by.css('[ng-click="ORD_FTLLO_Update($event)"]')).click();
		browser.sleep(1000);
		element(by.css('[ng-click="winmessage_Save_Click($event,winmessage)"]')).click();
		browser.sleep(1000);
		// Quay ve trang main
		element(by.css('[ng-click="ORD_FTLLO_Back($event)"]')).click();
		browser.sleep(1000);
	};
};

module.exports=new ORDOrder_FTLLO();