var ORDOrder_Excel =function()
{
	
};

module.exports=new ORDOrder_Excel();