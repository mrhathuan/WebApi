var ORDOrder_FCLIMEX =function()
{
		// ------------------- Tao mot don hang FCLIMEX ---------------------
	this.createFCLIMEXOrder = function(OrderCode,RequestDate,VesselNo,VesselName,TripNo,PartnerID,LocationDepotID,LocationFromID,ETD,LocationDepotReturnID,ArrayDetail)
	{
		// Ma don hang
		var txtCode = element(by.css("[ng-model='Item.Code']"));
		txtCode.clear();
		txtCode.sendKeys(OrderCode);
		// Ngay gui don hang
		var txtRequest = element(by.css("[k-ng-model='Item.RequestDate']"));
		txtRequest.clear();
		txtRequest.sendKeys(RequestDate);
		//So hieu tau
		var txtVesselNo = element(by.model("Item.VesselNo"));
		txtVesselNo.clear();
		txtVesselNo.sendKeys(VesselNo);
		//Ten tau VesselName
		txtVesselName = element(by.model("Item.VesselName"));
		txtVesselName.clear();
		txtVesselName.sendKeys(VesselName);
		//Ten tau TripNo
		var txtTripNo = element(by.model("Item.TripNo"));
		txtTripNo.clear();
		txtTripNo.sendKeys(TripNo);
		// Hang tau
		var cboShippingCo = element(by.css(".cboShippingCo.k-input.cus-combobox"));
		cboShippingCo.clear();
		cboShippingCo.sendKeys(PartnerID);
		browser.sleep(300);
		cboShippingCo.sendKeys(protractor.Key.ENTER);
		// Bai chua con
		var cboLocationDepotOptions = element(by.css(".cboLocationDepotOptions.k-input.cus-combobox"));
		cboLocationDepotOptions.clear();
		cboLocationDepotOptions.sendKeys(LocationDepotID);
		browser.sleep(300);
		cboLocationDepotOptions.sendKeys(protractor.Key.ENTER)
		//Diem nhan hang 
		var cboLocationFromID =  element(by.css(".cboLocationFrom.k-input.cus-combobox"));
		cboLocationFromID.clear();
		cboLocationFromID.sendKeys(LocationFromID);
		browser.sleep(300);
		cboLocationFromID.sendKeys(protractor.Key.ENTER);
		//ETD
		var txtETD = element(by.css("[k-ng-model='Item.ETD']"));
		txtETD.clear();
		txtETD.sendKeys(ETD);
		// Chon tab chi tiet van chuyen
		browser.sleep(200);
		var tab = element(by.css("li[tabindex='1']"));
		tab.click();
		browser.sleep(1000);
		// chon thong tin chung
		var cboLocationDepotReturnID =  element(by.css(".cbo_CO_LocationDepotOptions.k-input.cus-combobox"));
		cboLocationDepotReturnID.clear();
		cboLocationDepotReturnID.sendKeys(LocationDepotReturnID);
		browser.sleep(300);
		cboLocationDepotReturnID.sendKeys(protractor.Key.ENTER);
		for(var i = 0 ; i < ArrayDetail.length; i++)
		{
				// Them danh sach
				element(by.css('[ng-click="ORD_FCLIMEX_Container_AddNew($event,container_grid)"]')).click();
				browser.sleep(500);
				//Sua don hang
				element(by.css('[ng-click="ORD_FCLIMEX_Container_Edit($event,container_grid)"]')).click();
				browser.sleep(500);
				//So con
				var txtContainerNo = element(by.model("ContainerEdit.ContainerNo"));
				txtContainerNo.clear();
				txtContainerNo.sendKeys(ArrayDetail[i].ContainerNo);
				// Trong tai 
				var txtTon = element(by.model("ContainerEdit.Ton"));
				txtTon.clear();
				txtTon.sendKeys(ArrayDetail[i].Ton);
				// So Seal 1
				var txtSealNo1 = element(by.model("ContainerEdit.SealNo1"));
				txtSealNo1.clear();
				txtSealNo1.sendKeys(ArrayDetail[i].SealNo1);		
				// So Seal 2
				var txtSealNo2 = element(by.model("ContainerEdit.SealNo2"));
				txtSealNo2.clear();
				txtSealNo2.sendKeys(ArrayDetail[i].SealNo2);
				// Save chi tiet
				element(by.css('[ng-click="ORD_FCLIMEX_Container_Save($event,container_grid)"]')).click();
				browser.sleep(500);
				
		}
		browser.sleep(4000);
		element(by.css('[ng-click="ORD_FCLIMEX_Update($event)"]')).click();
		browser.sleep(1000);
		element(by.css('[ng-click="winmessage_Save_Click($event,winmessage)"]')).click();
		browser.sleep(1000);
		// Quay trang main
		element(by.css('[ng-click="ORD_FCLIMEX_Back($event)"]')).click();
		browser.sleep(1000);
		
	};
};

module.exports=new ORDOrder_FCLIMEX();