var ORDDashboard_Index =function()
{
	
};

module.exports=new ORDDashboard_Index();