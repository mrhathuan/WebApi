var ORDOrder_Index =function()
{
	// Button
	this.btnExcel = element(by.css('a[ui-sref="main.ORDOrder.Excel"]'));
	this.btnDN = element(by.css('a[ui-sref="main.ORDOrder.DN"]'));
	this.btnComment = element(by.css('a[ng-click="Comment_Click($event,order_grid)"]'));
	this.btnNew = element(by.css('a[ui-sref="main.ORDOrder.New"]'));
	this.btnSetting = element(by.css('a[ng-click="ShowSetting($event,order_grid)"]'));

	// Excel
	this.clickExcel =function()
	{
		this.btnExcel.click();
		browser.sleep(1000);
	};
	
	// DN
	this.clickDN =function()
	{
		this.btnDN.click();
		browser.sleep(1000);
	};
	
	// Comment
	this.clickOPS =function()
	{
		this.btnComment.click();
		browser.sleep(1000);
	};
		
	// New
	this.clickNew =function()
	{
		this.btnNew.click();
		browser.sleep(1000);
	};

	// Setting
	this.clickSetting =function()
	{
		this.btnSetting.click();
		browser.sleep(1000);
	};
	
	// ------------------------ Gui dieu phoi -------------------------------
	this.sendOPS = function(OrderCode)
	{		
		// Chon filter tat ca
		element(by.css('[ng-click="ViewDate_Click($event,order_grid)"]')).click();
		browser.sleep(1000);
		// chon don hang
		element(by.css('[data-text-field="Code')).clear();
		element(by.css('[data-text-field="Code')).sendKeys(OrderCode);
		element(by.css('[data-text-field="Code')).sendKeys(protractor.Key.ENTER);
		browser.sleep(1000);
		
		//click check box chon 
		element(by.css('[ng-click="gridChoose_Check($event,order_grid,order_gridChoose_Change)"]')).click();
		browser.sleep(2000);
		//gui dieu phoi
		element(by.css('[ng-click="OPS_Click($event,order_grid,routing_area_win)"]')).click();
		browser.sleep(1000);
		element(by.css('[ng-click="winmessage_Save_Click($event,winmessage)"]')).click();
		browser.sleep(1000);
	};
	
	
	//---------------------- Xoa 1 don hang -----------------------------
	this.deleteOrder = function(OrderCode){
		// Chon filter tat ca
		element(by.css('[ng-click="ViewDate_Click($event,order_grid)"]')).click();
		browser.sleep(1000);
		// Chon don
		element(by.css('[data-text-field="Code')).clear();
		element(by.css('[data-text-field="Code')).sendKeys(OrderCode);
		element(by.css('[data-text-field="Code')).sendKeys(protractor.Key.ENTER);
		browser.sleep(1000);
		element(by.css('[ng-click="gridChoose_Check($event,order_grid,order_gridChoose_Change)"]')).click();
		browser.sleep(2000);
		element(by.css('[ng-click="Del_Click($event,order_grid)"]')).click();
		browser.sleep(1000);
		element(by.css('[ng-click="winmessage_Save_Click($event,winmessage)"]')).click();
		browser.sleep(1000);
	};
	
	//---------------------- Comment cho don hang -----------------------------
	this.commentOrder = function(OrderCode, Comment){
		// Chon filter tat ca
		element(by.css('[ng-click="ViewDate_Click($event,order_grid)"]')).click();
		browser.sleep(1000);
		// Chon don
		element(by.css('[data-text-field="Code')).clear();
		element(by.css('[data-text-field="Code')).sendKeys(OrderCode);
		element(by.css('[data-text-field="Code')).sendKeys(protractor.Key.ENTER);
		browser.sleep(1000);
		element(by.css("tr[role='row'].ng-scope")).click();
		element(by.css('[ng-click="Comment_Click($event,order_grid)"]')).click();
		browser.sleep(1000);
		element(by.model('comment_text')).sendKeys(Comment);
		element(by.css('[ng-click="comment_send($event)"]')).click();
	};
	
	//---------------------- Sao chep don hang -----------------------------
	this.copyOrder = function(OrderCode, OrderCodeNew){
		// Chon filter tat ca
		element(by.css('[ng-click="ViewDate_Click($event,order_grid)"]')).click();
		browser.sleep(1000);
		// Chon don
		element(by.css('[data-text-field="Code')).clear();
		element(by.css('[data-text-field="Code')).sendKeys(OrderCode);
		element(by.css('[data-text-field="Code')).sendKeys(protractor.Key.ENTER);
		browser.sleep(1000);
		element(by.css('[ng-click="gridChoose_Check($event,order_grid,order_gridChoose_Change)"]')).click();
		browser.sleep(2000);
		element(by.css('[ng-click="Copy_Click($event,order_grid,copy_win,copy_grid)"]')).click();
		browser.sleep(1000);
		element(by.model('dataItem.NewCode')).sendKeys(OrderCodeNew);
		element(by.css('[ng-click="Copy_Save_Click($event,copy_grid,copy_win, order_grid)"]')).click();
		browser.sleep(1000);
		element(by.css('[ng-click="winmessage_Save_Click($event,winmessage)"]')).click();
		browser.sleep(1000);
	};
	
	this.excelOrder = function(TemplateCode,FilePath){
		this.btnExcel.click();
		browser.sleep(1000);
		element(by.css('[data-text-field="Name"]')).clear();
		element(by.css('[data-text-field="Name"]')).sendKeys(TemplateCode);
		browser.sleep(300);
		element(by.css('[data-text-field="Name"]')).sendKeys(protractor.Key.ENTER);
		browser.sleep(500);
		element(by.css("tr[role='row'].ng-scope")).click();
		//inport
		element(by.css('[ng-click="Excel_Template_Accept_Click($event,template_win,excel_template_grid)"]')).click();
		browser.sleep(1000);
		
		element(by.css('input[type="file"].ExcelOrder')).sendKeys(FilePath);
		browser.sleep(5000);
		
		
		element(by.css('[ng-click="Import_Click($event)"]')).click();
		browser.sleep(1000);
		
		element(by.css('[ng-click="winmessage_Save_Click($event,winmessage)"]')).click();
		browser.sleep(1000);
		
	};
};

module.exports=new ORDOrder_Index();