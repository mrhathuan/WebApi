var ORDOrder_New =function()
{
	this.newOrder = function(CustomerName, ServiceName, TransportName, ContractName){
		browser.sleep(1000);
		// Chon KH
		var cboCustomer = element(by.css(".cboCustomer.k-input.cus-combobox"));
		cboCustomer.clear();
		cboCustomer.sendKeys(CustomerName);
		browser.sleep(300);
		cboCustomer.sendKeys(protractor.Key.ENTER);
		// Chon dich vu
		var cbbService = element(by.css(".cboService.k-input.cus-combobox"));
		cbbService.clear();
		cbbService.sendKeys(ServiceName);
		browser.sleep(300);
		cbbService.sendKeys(protractor.Key.ENTER);
		// Chon loai van chuyen
		var cbbTransportMode = element(by.css(".cboTransportMode.k-input.cus-combobox"));
		cbbTransportMode.clear();
		cbbTransportMode.sendKeys(TransportName);
		browser.sleep(300);
		cbbTransportMode.sendKeys(protractor.Key.ENTER);
		browser.sleep(200);
		// Hop dong
		var cbbContract = element(by.css(".cboContract.k-input.cus-combobox"));
		cbbContract.clear();
		cbbContract.sendKeys(ContractName);
		browser.sleep(300);
		cbbContract.sendKeys(protractor.Key.ENTER);
		browser.sleep(200);
		element(by.css('[ng-click="ORDNew_Click($event)"]')).click();
		browser.sleep(1000);
	};
};

module.exports=new ORDOrder_New();