var OPSPage =function()
{
	// Button
	this.btnLTL = element(by.css('a[ng-click="Create_Click($event)"]'));
	this.btnFTL = element(by.css('a[ng-click="CreateFTL_Click($event)"]'));
	this.btnInput = element(by.css('a[ng-click="InputData_Click($event)"]'));

	// LTL
	this.clickLTL =function()
	{
		this.btnLTL.click();
		browser.sleep(1000);
	};
	
	// FTL
	this.clickFTL =function()
	{
		this.btnFTL.click();
		browser.sleep(1000);
	};
	
	// Input
	this.clickInput =function()
	{
		this.btnInput.click();
		browser.sleep(1000);
	};
	
};

module.exports=new OPSPage();