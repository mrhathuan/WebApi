var MainPage =function()
{
	// Tổng quan
	this.btnORDDashboard = element(by.css('a[ui-sref="main.ORDDashboard.Index"]'));
	// Vận hành
	this.btnORD = element(by.css('a[ui-sref="main.ORDOrder.Index"]'));
	this.btnOPS = element(by.css('a[ui-sref="main.OPSAppointment.Index"]'));
	this.btnMON = element(by.css('a[ui-sref="main.MONMonitor.Index"]'));
	this.btnPOD = element(by.css('a[ui-sref="main.PODInput.Index"]'));
	this.btnKPI = element(by.css('a[ui-sref="main.KPI.Index"]'));
	this.btnFIN = element(by.css('a[ui-sref="main.FIN.Index"]'));
	this.btnORDInspection = element(by.css('a[ui-sref="main.ORDInspection.Index"]'));
	// Báo cáo
	this.btnREP = element(by.css('a[ui-sref="main.PUBReport.Index"]'));
	// Phương tiện
	this.btnREP = element(by.css('a[ui-sref="main.PUBReport.Index"]'));
	this.btnMean = element(by.css('a[ui-sref="main.PUBMean.Index"]'));
	this.btnDriver = element(by.css('a[ui-sref="main.PUBDriver.Index"]'));
	// WorkFlow
	this.btnWFL = element(by.css('a[ui-sref="main.WFLSetting.Index"]'));
	// Thiết lập
	this.btnFLM = element(by.css('a[ui-sref="main.FLMSetting.Index"]'));
	this.btnCUS = element(by.css('a[ui-sref="main.PUBInstallCUS.Index"]'));
	this.btnVEN = element(by.css('a[ui-sref="main.PUBInstallVEN.Index"]'));
	// Thiết lập Excel
	this.btnSettingOrder = element(by.css('a[ui-sref="main.CUSSettingOrder.Index"]'));
	this.btnSettingPlan = element(by.css('a[ui-sref="main.CUSSettingPlan.Index"]'));
	// Quản trị
	this.btnAdmin = element(by.css('a[ui-sref="main.PUBAdmin.Index"]'));

	// Change view
	this.changeView =function(view)
	{
		browser.setLocation(view);
		browser.sleep(1000);
	};
	
	// Dashboard
	this.clickORDDashboard =function()
	{
		this.btnORDDashboard.click();
		browser.sleep(1000);
	};
	
	// Đơn hàng
	this.clickORD =function()
	{
		this.btnORD.click();
		browser.sleep(1000);
	};
	
	// Điều phối
	this.clickOPS =function()
	{
		this.btnOPS.click();
		browser.sleep(1000);
	};
		
	// Giám sát
	this.clickMON =function()
	{
		this.btnMON.click();
		browser.sleep(1000);
	};

	// Chứng từ
	this.clickPOD =function()
	{
		this.btnPOD.click();
		browser.sleep(1000);
	};
	
	// KPI
	this.clickKPI =function()
	{
		this.btnKPI.click();
		browser.sleep(1000);
	};
	
	// Thanh toán
	this.clickFIN =function()
	{
		this.btnFIN.click();
		browser.sleep(1000);
	};
	
	// Kiểm hóa
	this.clickORDInspection =function()
	{
		this.btnORDInspection.click();
		browser.sleep(1000);
	};
	
	// Báo cáo
	this.clickREP =function()
	{
		this.btnREP.click();
		browser.sleep(1000);
	};

	// Phương tiện
	this.clickMean =function()
	{
		this.btnMean.click();
		browser.sleep(1000);
	};
	
	// Tài xế
	this.clickDriver =function()
	{
		this.btnDriver.click();
		browser.sleep(1000);
	};
	
	// WorkFlow
	this.clickWFL =function()
	{
		this.btnWFL.click();
		browser.sleep(1000);
	};
	
	// Đội xe
	this.clickFLM =function()
	{
		this.btnFLM.click();
		browser.sleep(1000);
	};
	
	// Khách hàng
	this.clickCUS =function()
	{
		this.btnCUS.click();
		browser.sleep(1000);
	};
	
	// Đối tác
	this.clickVEN =function()
	{
		this.btnVEN.click();
		browser.sleep(1000);
	};
	
	// Đơn hàng
	this.clickSettingOrder =function()
	{
		this.btnSettingOrder.click();
		browser.sleep(1000);
	};
	
	// Kết hoạch phân tài
	this.clickSettingPlan =function()
	{
		this.btnSettingPlan.click();
		browser.sleep(1000);
	};
	
	// Quản trị
	this.clickAdmin =function()
	{
		this.btnAdmin.click();
		browser.sleep(1000);
	};
	
	this.createCodeCurrent = function(){
		var Code = "";
		var date = new Date();
		Code = date.getDate() + (date.getMonth()+ 1) + date.getFullYear() + date.getHours() + date.getMinutes() + date.getSeconds();
		return Code;
	};
};

module.exports=new MainPage();