var LoginPage =function()
{
	this.userName = element(by.model('login_Username'));
	this.passWord = element(by.model('login_Password'));
	this.btnLogin = element(by.css('input[type="submit"]'));
	
	this.enterUserPw=function(username, pwd)
	{
		this.userName.sendKeys(username);
		this.passWord.sendKeys(pwd);
	};
	
	this.clickDangNhap =function()
	{
		this.btnLogin.click();
	};
};

module.exports =new LoginPage();