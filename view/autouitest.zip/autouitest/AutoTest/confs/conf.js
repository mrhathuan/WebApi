// An example configuration file.
//var HtmlReporter = require('protractor-html-screenshot-reporter');

exports.config = {
  directConnect: true,

  // Capabilities to be passed to the webdriver instance.
  capabilities: {
    'browserName': 'chrome'
  },

  // Framework to use. Jasmine is recommended.
  framework: 'jasmine',

  // Spec patterns are relative to the location of the spec file. They may
  // include glob patterns.
  // suites: {
	  // def: '../tests/start.js',
	  // //login: '../tests/login/*_spec.js',
	  // // ord: ['../tests/login/*_spec.js','../tests/ord/*_spec.js'],
	  // // ops: ['../tests/login/*_spec.js','../tests/ops/*_spec.js'],
  // },
  specs: ['../tests/*_spec.js'],
  
  // Options to be passed to Jasmine.
  jasmineNodeOpts: {
	  showColors: true,
	  defaultTimeoutInterval: 1000000
  },
};
