var LoginPage =require('../pages/login_page.js');
describe('Login', function() {
   beforeEach(function() {
	  //browser.get('http://tmsdemo.smartlog.vn/');
	  browser.get('http://localhost:2743/');
	  browser.sleep(1000);
	  browser.driver.manage().window().maximize();
    });
	var MainPage =require('../pages/main_page.js');
    it('it should login', function() {
		var username = 'admin';
		var pwd = '123456789';
		LoginPage.enterUserPw(username, pwd);
		LoginPage.clickDangNhap();
		expect(element(by.binding('Default_UserName')).getText()).toEqual(username);
		browser.sleep(1000);

		//MainPage.changeView("ORDOrder_Index");

		//MainPage.changeView("PUBReportOwner_Index");
    });
});
