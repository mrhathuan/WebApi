var util =require('util');
describe('Test don hang', function() {
	var MainPage =require('../pages/main_page.js');
	var ORDOrder_Index =require('../pages/ORD/ORDOrder_Index.js');
	var ORDOrder_New =require('../pages/ORD/ORDOrder_New.js');
	var ORDOrder_LTLLO =require('../pages/ORD/ORDOrder_LTLLO.js');
	
    it('Tao don hang LTL roi xoa', function() {
		MainPage.clickORD();
		// Input đơn hàng
		// Main
		var CustomerName = 'Công ty bia';
		var ServiceName = 'Nội địa';
		var TransportName = 'LTL';
		var ContractName = 'Nội địa';
		// Thông tin chính
		var OrderCode = 'Auto_LTL' + MainPage.createCodeCurrent();
		var RequestDate = '13/07/2016 13:03';
		var ETD = '13/07/2016 13:03';
		var ETA = '13/07/2016 15:03';
		// Chi tiết
		var ArrayDetail = [];
		ArrayDetail.push({Quantity : 11, CBM : 11, Ton : 11, SO : "LTL_130393", DN : "LTL_130393"});
		ArrayDetail.push({Quantity : 11, CBM : 11, Ton : 11, SO : "LTL_130393", DN : "LTL_130393"});
		ArrayDetail.push({Quantity : 11, CBM : 11, Ton : 11, SO : "LTL_130393", DN : "LTL_130393"});
		ORDOrder_Index.clickNew();
		ORDOrder_New.newOrder(CustomerName, ServiceName, TransportName, ContractName);
		ORDOrder_LTLLO.createLTLOrder(OrderCode, RequestDate, ETD, ETA, ArrayDetail);
		ORDOrder_Index.deleteOrder(OrderCode);
	});
});
