var util =require('util');
describe('Test don hang', function() {
	var MainPage =require('../pages/main_page.js');
	var ORDOrder_Index =require('../pages/ORD/ORDOrder_Index.js');
	it('Chon don hang LTL nhan nut Excel', function() {
		MainPage.clickORD();
		var TemplateCode = "Bia_LTL";
		var FilePath = 'D:\\TMS\\AtuoUiTest\\AutoTest\\Bia_LTL.xlsx';
		var OrderCode = 'Auto_LTL';
		
		
		ORDOrder_Index.excelOrder(TemplateCode, FilePath);
		MainPage.clickORD();
		ORDOrder_Index.deleteOrder(OrderCode);
	});
});