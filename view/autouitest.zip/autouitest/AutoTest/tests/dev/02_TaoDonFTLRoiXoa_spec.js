var util =require('util');
describe('Test don hang', function() {
	var MainPage =require('../pages/main_page.js');
	var ORDOrder_Index =require('../pages/ORD/ORDOrder_Index.js');
	var ORDOrder_New =require('../pages/ORD/ORDOrder_New.js');
	var ORDOrder_FTLLO =require('../pages/ORD/ORDOrder_FTLLO.js');
	
    it('Tao don hang FTL roi xoa', function() {
		MainPage.clickORD();
		// Input đơn hàng
		// Main
		var CustomerName = 'Công ty bia';
		var ServiceName = 'Nội địa';
		var TransportName = 'FTL';
		var ContractName = '';
		// Thông tin chính
		var OrderCode = 'Auto_FTL' + MainPage.createCodeCurrent();
		var RequestDate = '13/07/2016 13:03';
		var ETD = '13/07/2016 13:03';
		var ETA = '13/07/2016 13:03';
		var GroupOfVehicle = "2 tấn";
		// Chi tiết
		var ArrayDetail = [];
		ArrayDetail.push({Quantity : 10, CBM :10 , Ton : 10, SO : "FTL_130392", DN : "FTL_130392"});
		ArrayDetail.push({Quantity : 11, CBM :11 , Ton : 11, SO : "FTL_130393", DN : "FTL_130394"});
		ArrayDetail.push({Quantity : 12, CBM :12 , Ton : 12, SO : "FTL_130394", DN : "FTL_130394"});
		
		ORDOrder_Index.clickNew();
		ORDOrder_New.newOrder(CustomerName, ServiceName, TransportName, ContractName);
		ORDOrder_FTLLO.createFTLOrder(OrderCode, RequestDate, ETD, ETA, GroupOfVehicle, ArrayDetail);
		ORDOrder_Index.deleteOrder(OrderCode);
    });
});
