var util =require('util');
describe('Test don hang', function() {
	var MainPage =require('../pages/main_page.js');
	var ORDOrder_Index =require('../pages/ORD/ORDOrder_Index.js');
	
    it('Comment Don hang ', function() {
		MainPage.clickORD();
		
		var OrderCode = '123';
		var Comment = '123456';
		
		ORDOrder_Index.commentOrder(OrderCode, Comment);
		
	});
});
