var util =require('util');
describe('Test don hang', function() {
	var MainPage =require('../pages/main_page.js');
	var ORDOrder_Index =require('../pages/ORD/ORDOrder_Index.js');
	var ORDOrder_New =require('../pages/ORD/ORDOrder_New.js');
	var ORDOrder_FCLIMEX =require('../pages/ORD/ORDOrder_FCLIMEX.js');
	
	it('Tao mot don hang FCL roi xoa', function(){
		MainPage.clickORD();
		// Input don hang
		//Main 
		var CustomerName = 'Công ty bia';
		var ServiceName = 'Nhập khẩu';
		var TransportName = 'FCL';
		var ContractName = '';
		//Thông tin chính
		var OrderCode = 'Auto_FCL' + MainPage.createCodeCurrent();
		var RequestDate = '13/07/2016 13:03';
		var VesselNo = 'Auto_FCL';
		var VesselName = 'Auto_FCL';
		var TripNo = 'Auto_FCL';
		var PartnerID = 'HoanHao';
		var LocationDepotID = 'CHOKWANG JOTUN LTD.';
		var LocationFromID = 'HP';
		var ETD = '13/07/2016 13:03';
		
		// Thông tin chi tiết
		var LocationDepotReturnID = 'CHOKWANG JOTUN LTD.';
		var ArrayDetail = [];
		ArrayDetail.push({ContainerNo : "123_FCL", Ton : 10, SealNo1 : "FCL_123", SealNo2 : "FCL_456"});
		ArrayDetail.push({ContainerNo : "456_FCL", Ton : 11, SealNo1 : "FCL_123", SealNo2 : "FCL_456"});
		ArrayDetail.push({ContainerNo : "789_FCL", Ton : 12, SealNo1 : "FCL_123", SealNo2 : "FCL_456"});
		
		ORDOrder_Index.clickNew();
		ORDOrder_New.newOrder(CustomerName, ServiceName, TransportName, ContractName);
		ORDOrder_FCLIMEX.createFCLIMEXOrder(OrderCode,RequestDate,VesselNo,VesselName,TripNo,PartnerID,LocationDepotID,LocationFromID,ETD,LocationDepotReturnID,ArrayDetail);
		ORDOrder_Index.deleteOrder(OrderCode);
	});
});
