var util =require('util');
describe('Test don hang', function() {
	var MainPage =require('../pages/main_page.js');
	var ORDOrder_Index =require('../pages/ORD/ORDOrder_Index.js');
	
    it('Comment Don hang ', function() {
		MainPage.clickORD();
		
		var OrderCode = '123';
		var OrderCodeNew = '123_456_123';
		
		ORDOrder_Index.copyOrder(OrderCode, OrderCodeNew);
		ORDOrder_Index.deleteOrder(OrderCodeNew);
	});
});
