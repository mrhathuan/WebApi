var util =require('util');
describe('Test loai bang lai', function() {
	var MainPage =require('../pages/main_page.js');
	var CATDrivingLicence_Index = require('../pages/CAT/CATDrivingLicence_Index.js');
	
	it('Tao mot loai bang lai', function(){
		MainPage.changeView("CATDrivingLicence_Index");
        browser.sleep(1000);
        CATDrivingLicence_Index.clickNew();
		//Main 
		var Code = 'Test001';
		var DrivingLicenceName = 'Test001';
		var VehicleWeight = 123;
        var TypeOfVehicleName = "Xe tải";
		var Description = 'Khong co mo ta';
		CATDrivingLicence_Index.AddNew(Code,DrivingLicenceName,VehicleWeight,TypeOfVehicleName,Description)
	    CATDrivingLicence_Index.clickSave();
	});
});