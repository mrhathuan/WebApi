﻿namespace TeduShop.Web.Models
{
    public class FooterViewModel
    {
        public string ID { set; get; }
        public string Content { set; get; }
    }
}